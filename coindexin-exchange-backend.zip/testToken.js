import mongoose from "mongoose";
import crypto from "crypto";
import User from "./models/User.js";  // ✅ correct relative path

mongoose.connect("mongodb://localhost:27017/cryptoExchange", {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

async function testToken() {
  const user = await User.findOne({ email: "gvsivagiri@gmail.com" });
  if (!user) return console.log("User not found");

  const token = crypto.randomBytes(20).toString("hex");
  user.passwordResetToken = crypto.createHash("sha256").update(token).digest("hex");
  user.passwordResetExpiry = Date.now() + 3600000;
  await user.save();

  console.log("Saved user:", user);
  mongoose.connection.close();
}

testToken();
